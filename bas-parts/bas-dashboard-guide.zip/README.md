# Ruby EMS BAS dashboard component

Copy `BasDashboard.tsx` and `BasDashboard.css` into your React admin portal.
Render `<BasDashboard tenantId={tenantId} siteId={siteId} baseUrl="http://localhost:4401" />`
for local testing. For an app served on another origin, configure a Vite proxy
for `/api/v1/telemetry` and omit `baseUrl`, or enable an appropriate CORS policy
on the telemetry service. Use the authenticated tenant ID in production.

The component displays stored samples in Overview and subscribes to the
existing SSE stream in Live. It uses `fetch` for SSE because EventSource
cannot set the required `x-tenant-id` header. A new device scoped history API
is included in the accompanying telemetry service files; build and restart
that service before opening the dashboard.

The supplied archives did not include the admin portal source. This component
is ready to integrate, but is not wired into the portal navigation yet.
