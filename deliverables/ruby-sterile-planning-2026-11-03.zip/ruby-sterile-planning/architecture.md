# Architecture decision record — standalone sterilization

Draft v0.1, November 3, 2026. Decision: one independent sterilization domain and
application; Athena is optional. No Athena purchase, service, database or licence
is a prerequisite for core sterile-processing operations.

## Repository baseline verified

The owner identified `hutpeter/Intrusionshield-platform`, branch
`feature/database-isolation-foundation`, commit
`dd282bac6b18192c2937e787b1714844a5a92b1c`. A separate managed checkout matches
that revision. The owner's four untracked paths have not been transferred or
changed. `main` is an older baseline and must not be substituted for this branch.
No AGENTS.md was found in the inspected branch tree.

The tracked repository uses Node 24+, TypeScript/NodeNext, pnpm 11.20.0, Express,
React applications, SQL Server provider infrastructure and workspace packages.
Existing locations include `packages/core` capability/entitlement definitions,
`packages/identity`, `packages/identity-persistence`,
`packages/internationalization`, `packages/his`, `packages/telemetry`,
`services/authentication`, `services/his`, `services/telemetry-energy`,
`apps/admin-portal` and `apps/solar-dashboard`. The active workspace already includes
`apps/*`, `packages/*` and `services/*`.

These are source observations, not a production-readiness claim. Source review of
`packages/identity/src/services/authorization-service.ts` shows permission matching;
that alone does not prove the complete entitlement/RBAC/ABAC production pipeline.
The October 21 database checkpoint reports development validation and outstanding
runtime/provisioning separation, sensitive-object permissions and audit protection.
No live SQL, service credentials, database permissions or Athena ZIP exports are
touched by this work. Device point registration exists; that does not prove a
working sterilizer protocol or clinically validated equipment integration.

## Proposed layout, consistent with the workspace

```text
apps/sterile-processing/                 Spanish-first operator application
services/sterile-processing/             Independent Express service/composition root
packages/sterile-processing/             Types, rules and repository contracts
services/sterile-processing/sql/         Separately reviewed sterilization DDL
services/sterile-processing/adapters/    Optional future Athena/device adapters
```

The initial domain/service paths are implemented; UI and optional adapter paths
remain proposed. Keep Core's existing
capability model intact; do not split Core packages merely to sell modules. Domain
logic must not import `@intrusionshield/his`, Athena SQL tables or energy product
business logic. An optional adapter may depend on public HIS contracts.

```mermaid
flowchart LR
    UI[Spanish-first sterilization UI] --> API[Independent sterilization service]
    API --> DOMAIN[Sterilization domain and repositories]
    DOMAIN --> DB[(Sterilization-owned storage)]
    API --> AUTH[Verified Ruby identity and authorization boundary]
    API --> LIC[Central capability and entitlement interface]
    API --> AUDIT[Transactional audit and outbox]
    API -. optional .-> HIS[Provider-neutral HIS adapter]
    HIS -. optional .-> ATHENA[Athena HIS]
    API -. optional .-> DEVICE[Read-only equipment adapters]
    DEVICE --> SIM[Isolated simulator or validated vendor interface]
```

A standalone deployment bundles or connects the required platform identity,
entitlement and audit components without requiring Athena. Optional integration
failures must not corrupt core processing records. Choose the deployment's exact
identity/session and facility-resolution adapters after checking current platform
interfaces and clinical shared-workstation requirements. Never invent a bypass
that trusts client-supplied tenant or role headers.

## Persistence boundary

Maintain SQL Server as the repository's current database technology unless the
owner explicitly changes it. The old suggestion `sterile.*` describes logical
ownership, not permission to create tables inside Athena's HIS database. Prefer
sterilization-owned storage with separate migrations and runtime credentials;
confirm a new database role through the existing isolation design. Do not use a
legacy default connection fallback to accidentally write into Platform, Telemetry,
BAS/EMS or HIS. Physical database/schema naming and provisioning remain reviewed
implementation decisions. No DDL is applied or live database connected now.

## Conceptual data model

| Aggregate/entity                       | Key relationships and invariants                                                                                            |
| -------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| FacilityReference                      | Tenant-scoped local reference to an authorized site/facility; independent of an Athena installation                         |
| InstrumentType                         | Catalogue definition, manufacturer/model/processing references; immutable identity and versioned changes                    |
| Instrument                             | Instance code/serial, type, owner facility, current custodian/location, condition and lifecycle; retirement retains history |
| IdentifierAlias                        | Tenant-unique identifier namespace/value mapped to an instrument, tray or package; no ambiguous scan authority              |
| TrayDefinition / TrayDefinitionVersion | Required composition and count; changes do not mutate historic assemblies                                                   |
| TrayAssembly / AssemblyItem            | Actual observed membership and inspection; an item cannot be simultaneously assigned twice                                  |
| ProcessingEpisode                      | One receipt/reprocessing lineage, facility/route/profile versions, links to prior episodes                                  |
| CleaningRecord / InspectionRecord      | Procedure reference, evidence, actor and completion/failure; defects drive holds                                            |
| Package / PackageContents              | Frozen composition, packaging provenance, unique label identity, expiry/condition policy                                    |
| Equipment / EquipmentQualification     | Local device identity, modality, status, maintenance/qualification due and evidence                                         |
| Load / LoadPackage                     | Frozen package assignment and program/profile; exclusive active membership                                                  |
| CycleEvidence / QualityResult          | Source/run identity, units/device/server times, completeness, physical/chemical/biological evidence                         |
| ReleaseDecision                        | Reviewer, evidence/profile versions and explicit decision; released history cannot be silently rewritten                    |
| InventoryPosition / CustodyTransfer    | Available state derives from release/condition/recall policy; one physical stock position                                   |
| ProcedureAssociation                   | Optional namespaced procedure/encounter/patient reference; unknown linkage explicitly represented                           |
| Recall / RecallScope / Retrieval       | Historical descendant graph, immediate holds, retrieval/disposition and authorized closure                                  |
| AuditEvent / Outbox / CommandReceipt   | Atomic state+audit, retry identity, ordered integration and reconciliation                                                  |

Server scope is `(tenantId, authorized facilityId, actorId)`. Tenant/facility foreign
keys, scoped uniqueness and application checks must agree. Patient data is not a
necessary dependency of initial instrument registration. Keep owner, current
custody, processing location and commercial tenant distinct.

## State and release model

The normal episode path is receipt → cleaning → inspection → assembly/packaging →
load → cycle evidence → required quality results → authorized release → sterile
inventory → distribution/use → new receipt. Defect, failure, quarantine and recall
are explicit holds that can interrupt progression. HLD has its own nonsterile
terminal/distribution route. A failed/pending/unknown result is not a success.

A release command must authorize the reviewer and facility, lock/check current
versions, verify complete approved-profile requirements, immutable load contents,
equipment qualification and package compatibility, then atomically write the
decision, inventory effect, audit and outbox. Concurrent commands/retries cannot
create two releases. Changes discovered afterward use a corrective event and
recall/review workflow; history is retained.

Initial instrument registration records **no claim of sterility** and has no
release endpoint. No generated demo should present registered stock as clinically
available. Simulated cycle evidence stays isolated from real release authority.

## Open design decisions

1. Clinical intended use/classification and approved process profiles (Q09/Q23).
2. Physical database role/schema and approved runtime/provisioning model (Q19).
3. Verified production authentication, facility authority, authorization and safe
   licence-expiry composition (Q08/Q21).
4. Identifier/label hardware and tracking granularity (Q05/Q06).
5. Automatic cycle import, device models/interfaces and HIS protocols (Q10/Q12/Q14).
6. On-premises/cloud, offline/downtime, performance, retention and recovery targets
   (Q16/Q17/Q19/Q20).

The initial implementation can use dependency-injected authorization/repository
contracts and test doubles. Production must fail closed when these adapters are
unconfigured; an in-memory test store is not durable hospital storage.
