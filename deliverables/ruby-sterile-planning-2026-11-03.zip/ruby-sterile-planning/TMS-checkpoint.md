# TMS pause checkpoint — November 3, 2026

TMS development is paused while Ruby Sterile Processing & Instrument Management
requirements are prepared. This is a handover, not a release approval.

## Preserved development baseline

- Functional code commit: `2c20c323ea11e2598f1684ac3aaa7f387c58780e`.
- Functional branch: `agent/client-portion-invoices`, pushed to origin.
- Draft PR: https://github.com/phowroyd99/TMS/pull/38, targeting
  `development/phase2-a`. GitHub CI run 118 passed when checked November 2.
  No merge or deployment is authorized by this checkpoint.
- Baseline validation: build, explicit browser-login build, typecheck, lint,
  formatting and 830 SQL-free checks passed. Real local Keycloak/Chromium checks
  verified Administrator/client invoices, receipts, correction review and privacy.
- Included functionality: companies/sites, therapists and client records,
  availability/services and scheduling, person-linked portal access, care/case
  notes, billing, payer coverage/routing, claim preparation, offline simulation,
  manual payer reconciliation and reviewed client-portion invoices.
- Username display is included. The owner confirmed it works. The owner has not
  yet reported completion of the new client-portion invoice workflow.

## Environment and local state

On November 3, the managed cloud Docker daemon was reachable and no containers
were running. `pnpm laptop:check` passed and reported existing Keycloak and Redis
files reusable. It started no services and accessed no SQL Server or Azure.
This is cloud verification, not a new check of the owner's Windows laptop.

Tracked configuration remains in `dev/keycloak/compose.yml`,
`dev/redis/compose.yml` and the laptop scripts. Generated private credentials,
realm, certificates, keys, SQLite database, browser artifacts and Redis data
remain ignored/local. No credential values are included in this document.

A private cloud dummy-data SQLite backup was created with the SQLite backup API
at `work/pause-checkpoint-2026-11-03/tms-preview.sqlite`; its integrity check passed.
It is ignored and is not in Git or the sterilization planning bundle. The original
file remains `work/keycloak-lab/data/tms-preview.sqlite`. This does not back up the
owner's laptop or Redis volume. Keep the laptop's private local files and Docker
volume separately under the owner's existing secure backup process.

Keycloak's development H2 runtime is disposable; private realm/configuration files
are preserved. Redis AOF sessions persist in their Docker volume; sessions still
expire normally. Never use `down -v`, delete ignored data, reinitialize credentials,
or reset certificates as part of ordinary restart.

## Outstanding work

1. Owner acceptance of the October 12 client-portion invoice and receipt workflow:
   see [complete steps](https://github.com/phowroyd99/TMS/blob/2c20c323ea11e2598f1684ac3aaa7f387c58780e/docs/client-portion-invoices.md). Do not confuse this invoice
   with the October 19 self-pay invoice. Both may have separate balances.
2. Paid invoice corrections need formal credit/refund workflows. Payment reversals
   only correct records; they do not move funds. Invoice exports and full tax/legal
   document requirements remain separate work.
3. Real payer integration and software-vendor onboarding remain deferred. Provider
   details will be supplied at the end, per owner instruction. Manual records and
   simulations do not establish provider enrollment or real claim submission.
4. Owner's remaining manual case-closure check has not been reported completed.
5. Production repository wiring, database migrations/integration verification,
   provisioning and operational security/recovery gates remain outstanding.
   Existing SQL driver mocks and safety tests do not prove live SQL operation.
6. Modular licensing is a requirement, not a completed implementation. Source
   review found no product entitlement/module licensing implementation. Define
   module registry, grants, enforcement, renewal/offline behaviour and audit before
   claiming the feature exists; authorization roles are not product licences.
7. The older Scheduling build concern is covered by the latest passing full build
   and browser-preview startup. No new Scheduling error was found at this pause.
   A different laptop-only error would need its exact message and commit.
8. Earlier docs describe older in-memory fixture stages. Current preview persists
   therapist/client records, appointments/planning, organizations/sites, portal
   ownership and client/therapist language preferences, care and financial records
   in SQLite. Fixed staff memberships and some fixture preferences remain test
   data; production membership persistence is not established by the preview.
9. Finish stacked-PR review, including earlier security PR #9 and the dependencies
   identified in PR #38, before any separately authorized merge/release.

## Restart on the owner's laptop

Open Ubuntu from PowerShell:

```powershell
wsl -d Ubuntu
```

Then, with the existing preview stopped:

```sh
cd ~/TMS
git status --short --branch
git fetch origin
git switch agent/client-portion-invoices
pnpm install --frozen-lockfile
pnpm laptop:check
pnpm laptop:start
```

If Git reports local modifications, preserve and inspect them before switching;
do not reset or discard them. Run one clone's preview at a time. After `Ready`,
open `https://127.0.0.1:9443` and use existing private local login details.
Ctrl+C stops owned services without deleting state. If a certificate has expired,
follow the existing explicit certificate-renewal instructions; keep TLS verification.
Do not run SQL migrations, SQL integration runners, Azure login or deployment as
part of this restart.

See [laptop preview](https://github.com/phowroyd99/TMS/blob/2c20c323ea11e2598f1684ac3aaa7f387c58780e/docs/laptop-preview.md), [Keycloak](https://github.com/phowroyd99/TMS/blob/2c20c323ea11e2598f1684ac3aaa7f387c58780e/docs/keycloak-lab.md),
[Redis](https://github.com/phowroyd99/TMS/blob/2c20c323ea11e2598f1684ac3aaa7f387c58780e/docs/redis-sessions.md) and [client-portion invoicing](https://github.com/phowroyd99/TMS/blob/2c20c323ea11e2598f1684ac3aaa7f387c58780e/docs/client-portion-invoices.md).
