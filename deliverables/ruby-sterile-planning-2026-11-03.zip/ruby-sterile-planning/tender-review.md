# Cajamarca evidence review — investment 2632846

Reviewed November 3, 2026. Source status: supplied English working translations;
no live procurement search, official Spanish-source verification or legal opinion
has been performed. A project investment code is not a procurement procedure ID.

## Source register

| ID  | Supplied document                                      | Useful locations                                          | Limits                                                                                                    |
| --- | ------------------------------------------------------ | --------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| D1  | 2632846_20261019_Details_English.docx                  | Form 08-C §§4.1–4.2, execution schedule                   | Planned dates/costs; physical-execution section has zero totals/blank records                             |
| D2  | 2632846_Technical_Documents_English.docx               | 2024 technical narrative §§1, 4.1–4.6, 5.1–5.2, 6, 9      | Organized translation omits editable maps/figures and some detailed tables; refers to Spanish 30-page PDF |
| D3  | 2632846_Maintenance_Commitment_English.docx            | Commitments dated October 11, 2023 and February 21, 2024  | Institutional O&M funding commitments, not a supplier software support contract                           |
| D4  | 2632846_Investment_Format_Approved_English.docx        | Form 07-C p2 E.1; p3 schedule; p4 maintenance             | Approved investment record; tiny scan text/signatures not fully deciphered                                |
| D5  | 2632846_Hospital_Sterilization_Investment_English.docx | SSI overview and execution phase; update October 18, 2026 | Investment monitoring; procurement data expressly reference-only                                          |
| D6  | 2632846_Cost_Structure_English.docx                    | §3 software description; §2 infrastructure costs          | Low-resolution scan transcription; infrastructure figure differs by S/30                                  |
| D7  | 2632846_Update_April_2026_English.docx                 | Execution modification April 28, 2026                     | One-page change summary; complete destination of linked record not legible                                |

Files are retained in `sources/`; stable text references use `extracted/` and the
section/table locator above. Document filename dates do not establish submission dates.

## What is actually supported

| Evidence ID | Finding                                                                                                                                 | Source                                       | Interpretation                                                                                              |
| ----------- | --------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| CAJ-001     | One information/traceability software system is included                                                                                | D1 §4.1; D2 §5.2; D4 investment items; D6 §3 | Explicit project scope; detailed contractual software requirements absent                                   |
| CAJ-002     | Reconstruct product history, identify supply-chain conditions and incident origin                                                       | D2 §5.1; D6 §3                               | Explicit traceability objective; granularity/identifier standard not specified                              |
| CAJ-003     | Current records are manual/basic software; production information, equipment utilization and instrument loss are problems               | D4 E.1                                       | Explicit problem statement; supports proposed electronic records/analytics, not a prescribed implementation |
| CAJ-004     | Central processing includes receipt, cleaning, preparation/packaging, sterilization, storage and distribution; disinfection also occurs | D2 §§4.1–4.2                                 | Operational context for workflow design, not a complete software acceptance list                            |
| CAJ-005     | Red/dirty, blue/clean and green/sterile zones are identified                                                                            | D2 §4.2; D6 §3                               | Facility configuration context; confirm actual approved layout                                              |
| CAJ-006     | Replacement scope is two steam sterilizers and one low-temperature sterilizer                                                           | D2 §§4.4, 5.2; D1 §4.1                       | Equipment context; supply/installation is not automatically the software vendor's scope                     |
| CAJ-007     | Described equipment types: dual-door electric steam 150/200 L; low-temperature H₂O₂ 70 L                                                | D2 §4.4                                      | No model, vendor, register map, API or validated recipe specification                                       |
| CAJ-008     | 24-hour sterile supply, quality assurance, biosafety, personnel training and equipment coordination are unit responsibilities           | D2 §4.1                                      | Service context; no numerical software availability/support SLA                                             |
| CAJ-009     | Software capital estimate is S/450,000; project total is S/3,203,288.21                                                                 | D1 §4.2; D2 §6.1; D4 schedule; D6 §3         | Investment allocation, not guaranteed available contract value or licence-only revenue                      |
| CAJ-010     | Software annual maintenance S/13,500 across ten-year planning horizon                                                                   | D4 p4 F.3                                    | Planning allowance, not an agreed support price, term or supplier obligation                                |
| CAJ-011     | Institutional O&M funding and training commitments exist                                                                                | D3 records                                   | Sustainability evidence; clarify which supplier services must be priced                                     |
| CAJ-012     | Ministry/hospital legal and technical references are cited                                                                              | D2 §1                                        | Applicability/current editions require qualified confirmation; no software certification established        |
| CAJ-013     | Investment intent is more capacity, better times/resource use and lower costs; 6% capacity increase recorded                            | D4 E.1                                       | Project-level benefit target, not an isolated software performance guarantee                                |
| CAJ-014     | Remodeling, replacement hardware and software sit within a wider investment                                                             | D1 §4.2; D2 §§5–6                            | Need to determine whether software is a separate lot, subcontract or bundled procurement                    |

No feature is marked 'tender compliant' on this evidence alone. The matrix
separates explicit project evidence, operational context, owner requirements and
proposed product controls. 'P0' means proposed MVP priority, not proven tender mandate.

## Commercial and schedule observations

- The S/450,000 software allocation appears consistently in the investment sources.
  Tax treatment, hardware/scanners/labels, integration, migration, training,
  maintenance, warranty and licence quantities are not allocated in a bid schedule.
- S/13,500 annual software maintenance is 3% of S/450,000. This calculation does
  not establish a sustainable support offer or a contractual price ceiling.
- D1 plans the software July 4–October 1, 2026, and O&M handover March 2, 2027.
  D5 lists overall execution June 2, 2026–January 30, 2027, last updated October 18.
  As of November 3, the October 1 planned software end has passed; this does not
  prove delivery, award, a closed tender or an extension.
- D2 uses 2024/four-period planning and mentions O&M starting May 2024; D4 starts
  financial execution March 2024 and maintenance February 2025. D7 records an
  April 28, 2026 modification without a current procurement calendar.
- D1 refers to Obras por Impuestos (works in lieu of taxes), while D4 references
  indirect administration by contract. Obtain the current approved mechanism,
  procedure identifier, procuring authority and any prime-contractor arrangements.

## Discrepancies to resolve

| Issue                          | Supplied evidence                                                                     | Required resolution                                                                |
| ------------------------------ | ------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Dates/deadline                 | 2024 planning vs 2026 execution vs 2027 handover/closeout                             | Obtain current formal bidding calendar/addenda and procurement status              |
| Executing authority            | Hospital/UEP 999 versus Regional Economic Development/UEP 775                         | Identify authorized contracting entity and technical decision maker                |
| Infrastructure cost            | D6 S/221,318.21; most other documents S/221,288.21                                    | Reconcile official signed budget; do not silently replace either figure            |
| Area                           | Existing rooms 455.7 m²; red-zone intervention 68.2 m²; investment quantity 548.13 m² | Confirm approved site/zone layout and work boundaries                              |
| Useful life                    | D2 refers to 12 years, D4 equipment useful lives 10 years                             | Confirm warranty, maintenance horizon and record-retention requirements separately |
| Asset location                 | Low-temperature asset red area in D6, blue zone in D2                                 | Obtain current equipment inventory/layout                                          |
| Software implementation detail | General traceability objective only                                                   | Obtain approved software technical specifications and acceptance criteria          |
| Physical execution record      | D1 zero/blank section, D5 active/approved status                                      | Do not interpret blank records as no work, no award or completed work              |

## Missing procurement information

Obtain current bases/pliego, approved technical file and software annexes, Spanish
originals, procedure number and public link, published addenda, deadlines,
eligibility/reference requirements, security/privacy/hosting conditions,
mandatory certificates, evaluation weights, bid guarantees, pricing/tax terms,
licensing/IP/source-code/escrow terms, supplier warranty/support, equipment and
HIS interfaces, deployment site constraints, training and signed acceptance plan.

These gaps do not prevent reusable product design. They prevent an honest claim
that the planned MVP meets all mandatory tender conditions or that the bid is
currently open. No contacts or submissions have been made.
