# Tender workstream and Ruby product roadmap

November 3, 2026. Prior 6–9-week MVP, 12–18-week pilot and four-week demonstration
estimates are unverified planning targets, not delivery promises. They depend on
source reuse, procurement requirements, device interfaces and clinical validation.
Re-estimate after the first five working days of measured output. Do not promise
January delivery based only on the recovered conversation.

## Workstream A — Cajamarca requirement/eligibility baseline

1. Obtain the formal current procurement procedure, software annex, Spanish
   originals, deadlines and eligibility terms; reconcile source conflicts.
2. Resolve questionnaire priority-A items with clinical, IT, procurement and
   equipment suppliers. Keep an answer and authoritative document revision log.
3. Convert confirmed mandatory clauses to contractual matrix rows. The current
   CAJ evidence rows describe project intent/context, not published tender clauses.
4. Establish priced installation, hardware, migration, integration, training,
   validation, licence and support boundaries and measurable acceptance criteria.
5. Obtain qualified applicability review and approved clinical profiles before
   real patient data or clinical release use.

No bid is submitted and no client/vendor is contacted by preparing these artifacts.

## Workstream B — Reusable standalone product

| Increment               | Concrete outcome                                                                                                                                                           | Dependencies / acceptance                                                                         |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| Foundation 1            | Isolated domain/service boundary, instrument types and instances, tenant/facility scope, audited changes, Spanish/English/French message catalogues, nonclinical API tests | Confirmed active repository branch; no Athena imports; no live SQL connection                     |
| Foundation 2            | Reviewed dedicated persistence adapter/schema, verified identity/capability/facility wiring, operator UI and local startup with synthetic data                             | Ruby isolation/security review; no unsafe default DB routing; no demo auth promoted to production |
| Traceability workflow   | Receipt, cleaning/HLD, inspection, tray versions, packaging/labels, loads and attributed manual cycle records                                                              | Agreed tracking levels, labels, approved local procedures                                         |
| Quality and release     | Profile-versioned indicator requirements, reviewer authority, holds and transactional release to inventory                                                                 | Clinical/quality sign-off of gate rules; AT-009/010/011                                           |
| Recall and distribution | Historical descendant impact, stock holds, custody and procedure references; incomplete associations explicit                                                              | Golden recall dataset and approved incident process                                               |
| Equipment demonstration | Isolated simulator with failures, gaps and duplicates; documented read-only import adapter                                                                                 | No claim of real equipment integration; AT-017                                                    |
| Pilot readiness         | Backup/restore, downtime, privacy/security, performance, localization/training and signed UAT                                                                              | Agreed targets, qualified clinical/regulatory review and deployment approval                      |
| Optional integrations   | Validated selected sterilizer adapters and Athena/other HIS contracts                                                                                                      | Device/vendor access and customer integration approvals                                           |
| Enterprise options      | Central processing/transfers, advanced analytics and customer-specific modules                                                                                             | Preserve shared domain, safety access, independent product licensing                              |

Core recall/quarantine, traceability integrity and authorized release are not
premium conveniences. Optional modules may add adapters, multi-facility operations
or analytics without disabling basic safety functions.

## First implementation slice — planned acceptance

- Instrument types and individual registration with stable IDs, Unicode names,
  duplicate-code checks, bounded lists and facility/tenant ownership.
- Controlled retirement with reason and optimistic version, retaining audit.
- API boundary depends on injected verified identity/central authorization and
  persistence contracts; default operation is fail-closed, not anonymous access.
- No sterilization/release, patient records, device control or Athena runtime
  dependencies in this slice.
- Separate SQL-free tests exercise registration, duplicate/stale writes, audit
  integrity, scoping and localization. Do not run the repository's live integration
  suites, migration runners or SQL connection scripts as a default test command.

## Local work preservation

The owner reported the following untracked entries on the active branch:
`i18n-shared-integration-current/database-isolation/`,
`i18n-shared-integration-current/services/`, `jest.config.mjs`, and
`ruby-test-results.txt`. They are absent from the remote checkout and have not been
read, discarded, staged or overwritten. Compare them before integrating a new
feature branch on the laptop; do not use a blanket `git add .` or reset.
