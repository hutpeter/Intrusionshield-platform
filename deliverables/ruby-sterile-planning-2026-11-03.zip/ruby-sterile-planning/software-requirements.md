# Software Requirements Specification — draft v0.1

Ruby Sterile Processing & Instrument Management — November 3, 2026.
Status: proposed baseline for owner/client review. No requirement below is claimed
implemented, clinically validated, certified or contractually accepted.

## Purpose, scope and intended use

Support accountable recording, review and traceability of reusable instrument,
tray, material and sterile-processing workflows. Authorized people apply approved
hospital procedures and make release decisions using complete evidence. The
initial product does not control sterilizer machinery, prescribe sterilization
recipes, automatically certify sterility or replace clinical judgment.

The first target is Cajamarca Regional Teaching Hospital. Installation is
independent of Athena HIS; shared Ruby capabilities may be used through verified
contracts. The deployment must have a complete identity/licensing/audit path even
when Athena is absent. The owner requires Spanish, English and French support,
with Spanish operational readiness prioritized for Cajamarca.

## Actors and authority

- Receiving/processing technician: assigned receipt, cleaning, inspection,
  assembly, packaging and load evidence tasks within permitted facilities.
- Qualified release reviewer: explicit release/rejection and required evidence
  review authority; technical Administrator status alone does not confer this.
- Inventory/distribution user: location, custody, allocation and receipt tasks.
- Quality/recall lead: quarantine, impact investigation, retrieval and disposition.
- Biomedical maintenance user: equipment availability and qualification evidence.
- Facility administrator: users, approved locations, nonclinical configuration.
- Auditor: scoped read/export only; no alteration or clinical release.
- Integration principal: narrowly scoped device/HIS ingestion, never human release.

Exact roles and separation-of-duties rules remain Q08. All transitions require
server-side authorization, including scanner and integration clients.

## Requirement interpretation

“Shall” describes a proposed product acceptance obligation. P0 is proposed MVP;
P1 is a later or customer-dependent capability. The provenance column in the CSV
separates explicit owner decisions, operationally derived needs and proposed
controls. CAJ IDs refer to evidence in tender-review.md, not published bidding
clauses. Detailed tender mandatory requirements remain unconfirmed.

## Requirements

### RSP-001 — Independent deployment (P0)

The sterilization UI and service shall install, authenticate users and complete their core workflows without Athena services, databases or licence. Optional adapters shall use versioned contracts and be disabled without breaking core functions.

Basis: Owner decision; Recovered plan; current owner instruction. Planned acceptance: AT-001. Clarification: Q01.

### RSP-002 — Tenant and facility scope (P0)

Every protected record and command shall carry server-verified tenant scope and permitted facility scope. Cross-facility ownership and custody shall be separate relationships; cross-tenant identifiers shall never authorize access.

Basis: Proposed product control; Owner multi-hospital direction; CAJ-005. Planned acceptance: AT-002. Clarification: Q07.

### RSP-003 — Identity and authorization (P0)

Server authorization shall combine centralized product entitlement, active membership, role permissions and relevant facility context. Technical administrators shall not gain clinical release authority merely by being administrators. Unauthenticated clinical writes shall fail closed.

Basis: Proposed product control; Owner shared Ruby direction. Planned acceptance: AT-002;AT-010. Clarification: Q08.

### RSP-004 — Instrument catalogue and instances (P0)

Maintain instrument type/catalogue and individually tracked instrument instances, stable IDs, local codes, manufacturer/model identifiers when supplied, ownership, current custody, condition and active status. Retiring an instrument shall preserve its history. Bulk materials shall have an explicitly distinct tracking model.

Basis: Operationally derived; CAJ-002;CAJ-003. Planned acceptance: AT-003. Clarification: Q05.

### RSP-005 — Tray definitions and assembly history (P0)

Version tray composition requirements and freeze actual membership and observed discrepancies for each assembly. Later edits shall not change past load membership or recall results. Items shall not belong to two simultaneous active assemblies.

Basis: Proposed product control; CAJ-002;CAJ-004; owner tray priority. Planned acceptance: AT-004;AT-014. Clarification: Q05.

### RSP-006 — Identifiers and scanning (P0)

Resolve approved instrument, tray and package identifiers through a keyboard/scanner workflow. Detect duplicate/unknown codes and require controlled reconciliation. Label reprints shall be audited; a reprint shall not create another physical processing record. Barcode formats and printer models remain to be agreed.

Basis: Proposed product control; CAJ-002; owner barcode priority. Planned acceptance: AT-003;AT-005. Clarification: Q06.

### RSP-007 — Contaminated receipt (P0)

Record receipt source, custodian, date/time, items or packs, condition and discrepancies. Receiving a used item shall begin a new processing episode and invalidate its prior available-sterile state without deleting historical evidence.

Basis: Operationally derived; CAJ-004;CAJ-005. Planned acceptance: AT-006. Clarification: Q04.

### RSP-008 — Cleaning and disinfection (P0)

Record cleaning/disinfection route, equipment or manual method, operator, completion and evidence under an approved procedure version. High-level disinfection shall remain distinct from sterilization and shall never produce a sterile label merely because it completed.

Basis: Operationally derived; CAJ-004. Planned acceptance: AT-006;AT-007. Clarification: Q04.

### RSP-009 — Inspection and defects (P0)

Record inspection results, missing/damaged items and maintenance/quarantine disposition. A failed or incomplete required inspection shall block progression into an accepted assembly/package. Approved exceptions require explicit authority and rationale and cannot bypass a failed safety condition.

Basis: Proposed product control; CAJ-003;CAJ-004. Planned acceptance: AT-007. Clarification: Q04.

### RSP-010 — Packaging and episode labels (P0)

Create a package/processing-episode identifier with frozen contents, packaging material/batch when required, operator, package date, storage/expiry policy and route compatibility. Repackaging shall create a linked new episode; previous labels shall no longer authorize dispatch.

Basis: Operationally derived; CAJ-004. Planned acceptance: AT-005;AT-008. Clarification: Q06;Q09.

### RSP-011 — Equipment availability (P0)

Register equipment identity, modality, facility/location, operating status, approved program references and maintenance/qualification due dates. Out-of-service, overdue-required-maintenance or unqualified equipment shall be blocked from new processing loads under the approved policy. Historical device identity shall remain retained.

Basis: Operationally derived; CAJ-006;CAJ-007;CAJ-008. Planned acceptance: AT-009. Clarification: Q10;Q11.

### RSP-012 — Load creation and contents (P0)

Create a uniquely identified load with equipment and approved program version and frozen package membership. Validate readiness, modality/material compatibility and exclusive active-load assignment. Changes after execution starts shall require a new controlled record, not silent editing.

Basis: Proposed product control; CAJ-002;CAJ-004;CAJ-007. Planned acceptance: AT-008;AT-009. Clarification: Q09;Q10.

### RSP-013 — Cycle evidence (P0)

Record source, equipment/run identity, program, start/end times and outcome, including aborted, failed, incomplete and unknown cycles. Manual transcription and simulated evidence shall be clearly identified. Missing or uncertain evidence shall not be interpreted as success.

Basis: Operationally derived; CAJ-002;CAJ-004;CAJ-007. Planned acceptance: AT-009;AT-017. Clarification: Q10;Q12.

### RSP-014 — Quality control and profile versions (P0)

Define locally approved, versioned required physical/chemical/biological checks by route and load class. Record indicator identity/lot/expiry and result where required, evidence, operator and review status. Pending required results, failed checks or missing evidence shall block release. Do not hardcode universal cycle temperatures, times, incubation requirements or indicator frequencies.

Basis: Proposed product control; CAJ-008; clinical safety design. Planned acceptance: AT-010. Clarification: Q09.

### RSP-015 — Authorized release (P0)

Only an authorized release reviewer may release a load against its frozen profile and evidence version after all required gates pass. Capture reviewer identity, rationale and decision time. Separation-of-duties policy shall be configurable; operator self-release shall be denied when that policy requires another reviewer. Telemetry alone shall never authorize release.

Basis: Proposed product control; CAJ-008; owner authorized-release priority. Planned acceptance: AT-010;AT-011. Clarification: Q08;Q09.

### RSP-016 — Sterile inventory (P0)

Only released, intact, unexpired/not-invalidated and nonquarantined packages shall appear as available sterile stock. Track location, custody and issued/reserved quantities without creating duplicate available stock. Package damage or expired policy conditions shall remove availability.

Basis: Operationally derived; CAJ-004;CAJ-005. Planned acceptance: AT-012. Clarification: Q13.

### RSP-017 — Distribution and returns (P0)

Record dispatch, recipient service/custodian, receipt acknowledgment and returns. Scan validation shall block recalled, quarantined, unreleased, damaged and invalid/expired packages. A return shall follow its approved condition-dependent route and shall not automatically restore sterile availability.

Basis: Operationally derived; CAJ-002;CAJ-004. Planned acceptance: AT-012;AT-013. Clarification: Q13.

### RSP-018 — Procedure associations (P0)

Allow authorized linkage to a procedure/encounter/patient reference via an optional provider-neutral interface or controlled local reference. Retain identifier namespace and association history; restrict patient details. When no association was captured, impact reports shall say unknown/incomplete rather than assert that no patient was affected.

Basis: Owner decision; Recovered plan: procedure/patient traceability. Planned acceptance: AT-014;AT-016. Clarification: Q14.

### RSP-019 — Recall and quarantine (P0)

Allow authorized quarantine/recall at equipment run, load, package, tray or instrument scope; determine descendants using historical contents and process relationships, immediately block further dispatch and record retrieval/disposition. Repeated alerts and reconciliation shall preserve a complete audit. Safety access shall not depend on optional analytics or Athena licences.

Basis: Owner decision; Recovered plan; CAJ-002 incident-origin objective. Planned acceptance: AT-014;AT-020. Clarification: Q15.

### RSP-020 — Audit and corrections (P0)

Every state-changing command shall atomically persist actor, tenant/facility, server time, record version, action, reason where required and correlation ID with the business change. Corrections shall append superseding evidence rather than overwrite released history. Database permissions and backup controls shall support the append-only application design; do not claim absolute tamper-proof storage.

Basis: Proposed product control; CAJ-002; owner audit direction. Planned acceptance: AT-011;AT-015. Clarification: Q16.

### RSP-021 — Production and traceability reports (P0)

Provide item/tray/package/load timelines, equipment throughput, turnaround and discrepancy/recall reports filtered by facility and time. Report source, status and missing evidence; distinguish project capacity objectives from software-measured outcomes. Exports shall respect user access.

Basis: Operationally derived; CAJ-002;CAJ-003;CAJ-013. Planned acceptance: AT-014;AT-018. Clarification: Q17.

### RSP-022 — Spanish-first localization (P0)

Externalize all screens, validation, status labels, notifications, reports and operator documentation. Supply Spanish es-PE as the initial target with English/French catalogues and completeness checks. Use configurable facility time zone, default America/Lima for the target, unambiguous localized dates, Unicode and local number formatting; retain canonical UTC instants.

Basis: Owner decision; Recovered plan: Spanish first-class; English/French included. Planned acceptance: AT-019. Clarification: Q18.

### RSP-023 — Privacy and data minimization (P0)

Minimize patient identifiers and clinical information, restrict them by task/facility, redact logs and telemetry, and enforce retention/export/deletion policies approved for the deployment. Determine controller/processor responsibilities and hosting/transfer constraints before real patient data is processed.

Basis: Proposed product control; CAJ-012; candidate Peruvian personal-data assessment. Planned acceptance: AT-002;AT-016. Clarification: Q14;Q16.

### RSP-024 — Transport and application security (P0)

Use verified TLS, protected secret configuration, secure sessions, server-side validation, parameterized persistence and authorization on all commands and exports. Cookie sessions shall include CSRF/origin defenses; do not store reusable bearer tokens in browser persistence. Security testing shall include cross-tenant/facility and privilege escalation attempts.

Basis: Proposed product control; Owner security direction. Planned acceptance: AT-002;AT-016. Clarification: Q19.

### RSP-025 — Concurrency and retry safety (P0)

Use optimistic versions, unique assignment constraints, transactions and idempotent command keys for processing, release, dispatch and recall. Concurrent attempts shall yield at most one accepted transition; uncertain retries shall resolve to the original outcome without duplicate labels or state changes.

Basis: Proposed product control; Traceability integrity design. Planned acceptance: AT-011;AT-015. Clarification: Q20.

### RSP-026 — Backup and downtime recovery (P0)

Provide encrypted/restricted backups, a tested restoration procedure, health monitoring and a hospital-approved downtime workflow. Reconcile paper/manual records after recovery with source attribution. Until offline-write synchronization is validated, disconnected workstations shall not independently release or dispatch electronically. RPO/RTO and availability targets require agreement.

Basis: Proposed product control; CAJ-008; owner quality direction. Planned acceptance: AT-015;AT-018. Clarification: Q20.

### RSP-027 — Evidence provenance and simulator isolation (P0)

Store device and server timestamps separately, units, source identity, import/run IDs and quality/uncertainty. Deduplicate delayed imports; surface gaps and clock skew. Simulated equipment data shall use a distinct environment/source and shall not satisfy real clinical release gates.

Basis: Proposed product control; Owner equipment-simulator direction. Planned acceptance: AT-017. Clarification: Q12.

### RSP-028 — Optional equipment adapters (P1)

Define provider-neutral read-only cycle-import adapters for documented device APIs/exports or protocols. Modbus/IoT shall be supported only where the selected device exposes a documented, licensed and validated interface. Do not start, stop or change sterilizer programs from this initial application.

Basis: Proposed product control; CAJ-007; owner Ruby integration direction. Planned acceptance: AT-017. Clarification: Q10;Q12.

### RSP-029 — Optional Athena/HIS adapter (P1)

Athena and other HIS integrations shall exchange only agreed identities, procedure links and events using adapters with retries, outbox/reconciliation, namespaces and audit. An unavailable HIS shall not invalidate sterile processing history or block permitted core workflows. No direct joins to Athena patient tables shall be required.

Basis: Owner decision; Current standalone/optional Athena instruction. Planned acceptance: AT-001;AT-016. Clarification: Q14.

### RSP-030 — Commercial module boundaries (P0)

Declare stable capabilities and dependency rules through the platform entitlement interfaces, not scattered licence checks. Core safety traceability, quarantine/recall, existing-record access and recovery shall not become inaccessible because an optional add-on expires. Define the supported core-licence-expiry safety mode with clinical/commercial owners; do not silently bypass authorization.

Basis: Owner decision; Recovered plan: modular licensing. Planned acceptance: AT-020. Clarification: Q21.

### RSP-031 — Retention and controlled exports (P0)

Retain readable original processing/release/recall relationships for the agreed retention period, including after asset retirement and optional integration removal. Controlled exports shall include provenance and access checks; lifecycle retention rules and legal holds shall be documented before purge is enabled.

Basis: Proposed product control; CAJ-002;CAJ-012. Planned acceptance: AT-016;AT-018. Clarification: Q16.

### RSP-032 — Installation, training and handover (P0)

Provide Spanish installation/operation/support documentation, role-based training scripts, a dummy-data exercise, backup/restore evidence and a signed user-acceptance checklist. Separate equipment-vendor training obligations from software training and clarify the priced scope.

Basis: Operationally derived; CAJ-008;CAJ-011; D2 §8. Planned acceptance: AT-018;AT-019. Clarification: Q22.

### RSP-033 — Quality and operational targets (P0)

Agree workload, scan/query response times, 24-hour service assumptions, availability, accessibility, browser/scanner/printer support and recovery targets. Measure them on the agreed environment and dataset. Candidate interactive p95 under two seconds is a planning target, not a confirmed tender requirement.

Basis: Proposed product control; CAJ-008; owner SRS direction. Planned acceptance: AT-018. Clarification: Q17;Q20.

### RSP-034 — Clinical procedure configuration (P0)

Only approved qualified roles may activate or revise clinical processing/indicator profiles. Record author, clinical approval and effective period; new versions shall not retroactively change completed loads. Software shall record and enforce approved workflows, not invent or clinically validate sterilization recipes.

Basis: Proposed product control; CAJ-012; owner quality direction. Planned acceptance: AT-007;AT-010. Clarification: Q09;Q23.

### RSP-035 — Multi-facility transfers (P1)

Represent owner facility, processing facility and present custodian independently with stable transfer identifiers. Later transfer workflows shall record dispatch/receipt conditions and missing items without merging tenants or losing recall links. Shared access across tenants requires an explicit approved agreement.

Basis: Owner roadmap; Recovered plan: centralized/multi-hospital deployment. Planned acceptance: AT-002;AT-013. Clarification: Q07.

### RSP-036 — Initial data migration (P0)

Import an agreed instrument/tray/equipment baseline through validation, duplicate handling and reconciliation reports. Unverified historical records shall not create current sterile availability or backdated release approvals. Preserve source and import batch identifiers.

Basis: Operationally derived; CAJ-003. Planned acceptance: AT-003;AT-015. Clarification: Q05;Q24.

## Quality, compliance and change control

Use ISO/IEC/IEEE 29148 as a candidate requirements-organization reference and
ISO/IEC 25010 quality characteristics as a review checklist. These choices do not
make them tender mandates or establish certified conformance. Source-cited
Peruvian requirements, candidate process standards and conditional medical-device
software standards are separately classified in standards-applicability.md.

Before design freeze, resolve intended use/classification, approved hospital SOPs,
privacy/hosting/retention, device models, procurement requirements and acceptance
signatories. Maintain hazards and mitigations for false release, lost traceability,
wrong-patient associations, duplicate processing, stale labels and recall failure.
Clinical/quality owners review profile changes and workflow validation evidence.

Every requirement change shall retain its ID, reason, source, affected design/test
links and review status. Implementation claims require a commit and executed
acceptance evidence. Candidate thresholds and unresolved values are not quietly
converted to contractual promises. The acceptance plan is pending execution.
