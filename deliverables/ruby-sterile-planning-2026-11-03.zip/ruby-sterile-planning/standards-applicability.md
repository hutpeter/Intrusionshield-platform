# Standards and regulatory applicability register — draft

This register identifies review candidates and references cited in the uploaded
technical narrative. No paywalled standards have been reviewed in full, current
editions have not been verified, and applicability/certification is not asserted.
Do not substitute a standards list for an intended-use, jurisdiction and contract
assessment by the hospital and qualified regulatory/clinical personnel.

## Source-cited Peruvian references

D2 §1 cites the following. They are evidence of the investment's framework;
they are not automatically software certification requirements.

| ID     | Reference as supplied                                                                        | Relevance / action                                                                                 | Requirement links                     |
| ------ | -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- | ------------------------------------- |
| REG-01 | Legislative Decree 1252; Directorial Resolutions 001-2019-EF/63.01, 006-2020 and 004-2019-EF | Investment governance/IOARR registration; obtain current approved procurement file                 | Tender review CAJ-014; Q01–Q03        |
| REG-02 | Law 26842, General Health Law                                                                | Health-service framework; determine current applicable obligations                                 | RSP-014, RSP-015, RSP-034; Q23        |
| REG-03 | Ministerial Resolution 1472-2002-SA/DM, Hospital Disinfection and Sterilization Manual       | Review current applicability and hospital-approved procedures; do not invent cycle criteria        | RSP-008–RSP-017, RSP-034; Q04/Q09/Q23 |
| REG-04 | Law 29783; Supreme Decree 012-2014-TR                                                        | Occupational safety/incident reporting; evaluate software evidence needs versus employer duties    | RSP-009, RSP-011, RSP-019; Q04/Q23    |
| REG-05 | Ministerial Resolution 372-2011/MINSA                                                        | Environmental cleaning/disinfection guidance; distinguish environment from device-processing scope | RSP-008, RSP-032; Q04/Q23             |
| REG-06 | Ministerial Resolution 660-2014/MINSA; NTS 110-MINSA/DGIEM-V.01                              | Second-level facility infrastructure/equipment context; confirm current edition/site SOPs          | RSP-002, RSP-011; Q07/Q23             |
| REG-07 | Law 27446; Supreme Decree 019-2009-MINAM                                                     | Environmental investment framework; clarify obligations outside software supply                    | CAJ-014; Q01/Q23                      |

The technical narrative also cites Law 29090 in its remodeling discussion. This
is infrastructure context, not a software functional requirement.

## Additional legal assessment to obtain

Peruvian personal-data Law 29733 and its current implementing framework are
candidate obligations to verify for personal/patient data, hosting, processors,
security, transfers, retention and rights. This reference is a proposed assessment
item, not a claim it was explicitly listed in the supplied project sources.
Determine intended use and whether local medical-device/software regulation or
registration applies. Do not assume an administrative traceability description
exempts software with clinical decision functions, or that EU/US rules necessarily
apply to a Peruvian deployment. See Q16/Q19/Q23.

## Candidate process and product references

| ID     | Candidate reference                               | Appropriate use and limit                                                                                                                                                             | Requirement / test links                                   |
| ------ | ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------- |
| STD-01 | ISO 17665                                         | Moist-heat process validation/routine-control context; record locally approved profiles/evidence, not certify the sterilizer process                                                  | RSP-012–RSP-015, RSP-034; AT-009/010                       |
| STD-02 | ISO 22441; ISO 14937 where applicable             | Vaporized hydrogen peroxide and general sterilization-process context; exact selected modality/technology must be established, including any plasma-specific vendor process           | RSP-011–RSP-015, RSP-034; AT-009/010                       |
| STD-03 | ISO 15883 series                                  | Washer-disinfector context if in scope; distinguish cleaning/disinfection evidence from sterile release                                                                               | RSP-008, RSP-011; AT-006/007                               |
| STD-04 | ISO 11607 series                                  | Packaging/sterile barrier process context; do not claim label or packaging validation from software records alone                                                                     | RSP-010, RSP-016; AT-005/012                               |
| STD-05 | ISO 11138 / ISO 11140 series                      | Biological/chemical indicator context; applicable types/frequencies and hold rules must come from approved local profiles                                                             | RSP-014–RSP-015; AT-010                                    |
| STD-06 | ISO 17664 series                                  | Manufacturer's processing information; capture approved references and material/modality compatibility                                                                                | RSP-004, RSP-012, RSP-034; AT-008/009                      |
| STD-07 | ISO/IEC/IEEE 29148                                | Candidate requirements structure and traceability practice; no certification claim                                                                                                    | SRS, matrix and all planned tests                          |
| STD-08 | ISO/IEC 25010                                     | Quality characteristic checklist; convert agreed usability/reliability/performance needs to measurable tests                                                                          | RSP-026, RSP-033; AT-018/019                               |
| STD-09 | ISO/IEC 27001; ISO 27799                          | Security-management/health-information control references; implementing selected controls does not certify an organization                                                            | RSP-003, RSP-020, RSP-023–RSP-026, RSP-031; AT-002/015/016 |
| STD-10 | IEC 62304; ISO 14971; ISO 13485                   | Conditional software lifecycle, risk and quality-management requirements if intended use/classification/contract makes them applicable; do not silently impose or claim certification | RSP-014–RSP-015, RSP-019, RSP-034; Q23                     |
| STD-11 | IEC 82304-1                                       | Candidate health software product-safety assessment; applicability to defined product and deployment requires review                                                                  | SRS intended use, risk register and validation plan; Q23   |
| STD-12 | WCAG 2.2 AA                                       | Proposed accessibility target for keyboard, contrast, focus and error workflows, subject to agreed scope; not claimed a tender clause                                                 | RSP-022, RSP-033; AT-019                                   |
| STD-13 | HL7 FHIR / HL7 v2; GS1 identifiers where required | Interoperability/identification options only after receiving customer contracts and device/label constraints; not automatic mandatory technology choices                              | RSP-006, RSP-018, RSP-029; AT-003/016; Q06/Q14             |

## Evidence required before any compliance claim

For each applicable obligation, record exact current edition/legal text and
contract clause, applicability rationale, accountable owner, mapped requirements,
implementation commit/configuration, executed test or process evidence, reviewer,
remaining deviations and approval. Track clinical process validation separately
from software verification and from organization-level certification. Manufacturer
instructions, equipment qualification, approved SOPs and qualified release staff
remain essential even when the software tests pass.
