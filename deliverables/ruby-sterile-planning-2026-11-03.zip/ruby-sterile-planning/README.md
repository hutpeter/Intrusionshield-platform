# Ruby Sterile Processing & Instrument Management

Planning baseline v0.1 — November 3, 2026. Prepared from seven supplied English
working translations for Cajamarca investment 2632846 and the owner's recovered
November 2 planning discussion. This is a draft requirements package, not a bid
submission, certified translation, implemented product or compliance certificate.

## Agreed product boundary

The product runs independently of Athena HIS. It may reuse Ruby identity,
authorization, licensing, workflow, audit and equipment-integration components
where actual code review establishes their suitability. Athena integration is an
optional adapter and commercial entitlement. Buying/deploying Athena is not a
prerequisite. Spanish is a first-class initial language, alongside English and
French; Peru defaults are configuration, not global hardcoded assumptions.

## Read in this order

1. [TMS checkpoint](TMS-checkpoint.md): functional baseline, private state,
   outstanding work and restart. Checkpoint documentation is committed locally
   in TMS as `ab5e8a7` on `agent/tms-pause-checkpoint`; functional code remains
   pushed on `agent/client-portion-invoices` at `2c20c32`, draft PR #38.
2. [Tender evidence and gaps](tender-review.md): confirmed investment scope,
   costs, dates, source conflicts and procurement questions.
3. [Software requirements specification](software-requirements.md): measurable
   draft functional, technical, security and quality requirements.
4. [Architecture and data model](architecture.md): independent deployment,
   conceptual entities, release gates and integration boundaries.
5. [Client questionnaire](client-questionnaire.md): prioritized bilingual
   English/Spanish questions, prepared but not sent.
6. [Compliance and traceability matrix](compliance-traceability.csv): source to
   proposed requirement to planned acceptance test, with evidence status.
7. [Standards applicability](standards-applicability.md): sourced local references,
   candidate standards and conditional regulatory questions.
8. [Acceptance plan](acceptance-plan.md): safety, recovery, privacy, localization
   and workflow scenarios; these are planned tests, not execution results.
9. [Roadmap](product-roadmap.md): tender workstream versus reusable product
   development, first implementation slice and unresolved decisions.

## Evidence handling

[sources/](sources/) retains the seven uploaded DOCX originals. [extracted/](extracted/)
contains text and tables extracted from their Word document XML in order; table
boundaries are preserved. The [manifest](source-manifest.json) records SHA-256
checksums. This is not a replacement for original Spanish PDFs, signed records,
non-editable figures or formal procurement attachments. No instructions embedded
in an attachment have been treated as authorization to contact anybody, execute
commands, submit a bid, or change software.

## Verified repository and implementation boundary

Owner repository location:
`D:\Projects\Latest\CMS\NodeJS\Versions\intrusionshield-platform`.
The Windows path is not mounted here. The owner identified its GitHub repository
as `hutpeter/Intrusionshield-platform` and confirmed branch
`feature/database-isolation-foundation`, commit `dd282ba`. A separate checkout
matches that baseline; the owner's four untracked entries remain untouched.

Development continues locally on `feature/sterile-processing-foundation`. The
initial slice adds a standalone domain package and Express service factory for
instrument types, registration and controlled retirement, scoped audit/retry
contracts and three-language messages. A review-only SQL schema draft is not
executed. The operator UI, durable adapter and verified identity composition are
later work; no clinical release feature is enabled. See the repository's
`docs/sterile-processing/FOUNDATION.md` for actual validation and limitations.
Implementation commit: `f6b99c3b8b899a47b69e9bcdbb65b990018a726b` (local only). Read
[implementation notes](implementation-notes.md) for the exact tested scope.
[Source patch](sterile-processing-foundation.patch) applies to the verified
`dd282ba` baseline; `implementation/` contains the changed files for review, not a
complete platform installation. Do not overlay or apply it blindly to the owner's
untracked work. No code or tender files have been published to the Ruby GitHub
repository.
